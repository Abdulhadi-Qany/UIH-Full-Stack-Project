using Microsoft.EntityFrameworkCore;
using UIH.Api.Models;
namespace UIH.Api.Data;
public class UiHDbContext(DbContextOptions<UiHDbContext> options) : DbContext(options) {
 public DbSet<Department> Departments => Set<Department>();
 public DbSet<Doctor> Doctors => Set<Doctor>();
 public DbSet<NewsArticle> News => Set<NewsArticle>();
 public DbSet<AppointmentEnquiry> AppointmentEnquiries => Set<AppointmentEnquiry>();
 public DbSet<ContactEnquiry> ContactEnquiries => Set<ContactEnquiry>();
 public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
 protected override void OnModelCreating(ModelBuilder modelBuilder) {
  modelBuilder.Entity<Department>().HasIndex(x => x.Slug).IsUnique();
  modelBuilder.Entity<AppointmentEnquiry>().HasIndex(x => new { x.CreatedAtUtc, x.Status });
  modelBuilder.Entity<NewsArticle>().HasIndex(x => new { x.IsPublished, x.PublishedAt });
 }
}
