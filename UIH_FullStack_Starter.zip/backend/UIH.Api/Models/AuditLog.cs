using System.ComponentModel.DataAnnotations;
namespace UIH.Api.Models;
public class AuditLog {
 public long Id {get;set;}
 [MaxLength(120)] public string? ActorId {get;set;}
 [Required, MaxLength(100)] public string Action {get;set;} = "";
 [MaxLength(100)] public string EntityType {get;set;} = "";
 [MaxLength(120)] public string? EntityId {get;set;}
 [MaxLength(80)] public string? IpAddress {get;set;}
 public DateTime CreatedAtUtc {get;set;} = DateTime.UtcNow;
}
