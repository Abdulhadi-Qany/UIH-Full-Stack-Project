using System.ComponentModel.DataAnnotations;
namespace UIH.Api.Models;
public class Department {
 public int Id {get;set;}
 [Required, MaxLength(120)] public string Name {get;set;} = "";
 [Required, MaxLength(140)] public string Slug {get;set;} = "";
 [MaxLength(2000)] public string Description {get;set;} = "";
 [MaxLength(500)] public string? ImageUrl {get;set;}
 public bool IsPublished {get;set;}
 public DateTime CreatedAtUtc {get;set;} = DateTime.UtcNow;
}
