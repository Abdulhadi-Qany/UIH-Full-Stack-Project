using System.ComponentModel.DataAnnotations;
namespace UIH.Api.Models;
public class NewsArticle {
 public int Id {get;set;}
 [Required, MaxLength(200)] public string Title {get;set;} = "";
 [Required, MaxLength(4000)] public string Summary {get;set;} = "";
 [MaxLength(10000)] public string? Body {get;set;}
 [MaxLength(500)] public string? ImageUrl {get;set;}
 public DateTime? PublishedAt {get;set;}
 public bool IsPublished {get;set;}
}
