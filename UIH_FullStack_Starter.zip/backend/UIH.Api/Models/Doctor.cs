using System.ComponentModel.DataAnnotations;
namespace UIH.Api.Models;
public class Doctor {
 public int Id {get;set;}
 [Required, MaxLength(160)] public string FullName {get;set;} = "";
 [MaxLength(100)] public string Title {get;set;} = "";
 [MaxLength(120)] public string Specialty {get;set;} = "";
 [MaxLength(200)] public string Qualifications {get;set;} = "";
 [MaxLength(500)] public string? Bio {get;set;}
 [MaxLength(500)] public string? ImageUrl {get;set;}
 [MaxLength(120)] public string Languages {get;set;} = "Dari, Pashto";
 public bool IsActive {get;set;}
}
