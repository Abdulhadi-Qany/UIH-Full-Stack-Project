using System.ComponentModel.DataAnnotations;
namespace UIH.Api.Models;
public class ContactEnquiry {
 public int Id {get;set;}
 [Required, MaxLength(120)] public string FullName {get;set;} = "";
 [Required, MaxLength(200)] public string Email {get;set;} = "";
 [MaxLength(40)] public string? Phone {get;set;}
 [Required, MaxLength(200)] public string Subject {get;set;} = "";
 [Required, MaxLength(3000)] public string Message {get;set;} = "";
 public DateTime CreatedAtUtc {get;set;} = DateTime.UtcNow;
}
