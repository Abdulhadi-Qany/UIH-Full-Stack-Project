using System.ComponentModel.DataAnnotations;
namespace UIH.Api.Models;
public class AppointmentEnquiry {
 public int Id {get;set;}
 [Required, MaxLength(120)] public string FullName {get;set;} = "";
 [Required, MaxLength(40)] public string Phone {get;set;} = "";
 [EmailAddress, MaxLength(200)] public string? Email {get;set;}
 [Required, MaxLength(120)] public string Department {get;set;} = "";
 public DateOnly? PreferredDate {get;set;}
 [Required, MaxLength(2000)] public string Message {get;set;} = "";
 [MaxLength(5)] public string Language {get;set;} = "en";
 public string Status {get;set;} = "New";
 public DateTime CreatedAtUtc {get;set;} = DateTime.UtcNow;
}
