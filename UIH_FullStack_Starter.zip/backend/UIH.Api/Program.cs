using Microsoft.EntityFrameworkCore;
using UIH.Api.Data;
using UIH.Api.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<UiHDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("UiH") ??
      "Host=localhost;Port=5432;Database=uih;Username=uih_app;Password=local-dev-only-change-me"));
builder.Services.AddCors(options => options.AddPolicy("Frontend", policy =>
    policy.WithOrigins(builder.Configuration.GetSection("AllowedOrigins").Get<string[]>() ??
        ["http://localhost:5173"]).AllowAnyHeader().AllowAnyMethod()));
var app = builder.Build();
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }
app.UseHttpsRedirection();
app.UseCors("Frontend");
app.MapControllers();
app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "UIH.Api" }));
using (var scope = app.Services.CreateScope()) {
    var db = scope.ServiceProvider.GetRequiredService<UiHDbContext>();
    try {
        db.Database.EnsureCreated();
        if (!db.Departments.Any()) {
            db.Departments.AddRange(
                new Department { Name="Cardiology", Slug="cardiology", Description="Heart and cardiovascular care information.", IsPublished=true },
                new Department { Name="Obstetrics & Gynaecology", Slug="ob-gyn", Description="Women’s health and maternity care information.", IsPublished=true },
                new Department { Name="Paediatrics", Slug="paediatrics", Description="Healthcare information for infants and children.", IsPublished=true },
                new Department { Name="Orthopaedics", Slug="orthopaedics", Description="Bone, joint and musculoskeletal care information.", IsPublished=true },
                new Department { Name="General Surgery", Slug="general-surgery", Description="Surgical consultation and patient information.", IsPublished=true },
                new Department { Name="Radiology & Imaging", Slug="radiology", Description="Diagnostic imaging service information.", IsPublished=true },
                new Department { Name="Laboratory", Slug="laboratory", Description="Laboratory and diagnostic testing information.", IsPublished=true },
                new Department { Name="Emergency Services", Slug="emergency", Description="Emergency service information. Contact the hospital directly for urgent care.", IsPublished=true }
            );
            db.SaveChanges();
        }
    } catch (Exception ex) { app.Logger.LogWarning(ex, "Database seed skipped; check database configuration."); }
}
app.Run();
