using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UIH.Api.Data;
using UIH.Api.Models;
namespace UIH.Api.Controllers;
public record AppointmentEnquiryRequest(string FullName,string Phone,string? Email,string Department,DateOnly? PreferredDate,string Message,string? Language);
[ApiController, Route("api/appointment-enquiries")]
public class AppointmentEnquiriesController(UiHDbContext db) : ControllerBase {
 [HttpPost] public async Task<IActionResult> Create(AppointmentEnquiryRequest request) {
  if(string.IsNullOrWhiteSpace(request.FullName)||string.IsNullOrWhiteSpace(request.Phone)||
     string.IsNullOrWhiteSpace(request.Department)||string.IsNullOrWhiteSpace(request.Message))
    return BadRequest("Name, phone, department and message are required.");
  if(request.FullName.Length>120||request.Phone.Length>40||request.Department.Length>120||request.Message.Length>2000)
    return BadRequest("One or more fields exceed the allowed length.");
  if(request.PreferredDate.HasValue && request.PreferredDate.Value < DateOnly.FromDateTime(DateTime.UtcNow))
    return BadRequest("Preferred date cannot be in the past.");
  var item=new AppointmentEnquiry {FullName=request.FullName.Trim(),Phone=request.Phone.Trim(),
   Email=string.IsNullOrWhiteSpace(request.Email)?null:request.Email.Trim(),Department=request.Department.Trim(),
   PreferredDate=request.PreferredDate,Message=request.Message.Trim(),Language=request.Language??"en"};
  db.AppointmentEnquiries.Add(item);
  db.AuditLogs.Add(new AuditLog{Action="AppointmentEnquiry.Created",EntityType="AppointmentEnquiry",EntityId="pending"});
  await db.SaveChangesAsync();
  return Created($"/api/appointment-enquiries/{item.Id}",new{item.Id,item.Status,item.CreatedAtUtc});
 }
}
