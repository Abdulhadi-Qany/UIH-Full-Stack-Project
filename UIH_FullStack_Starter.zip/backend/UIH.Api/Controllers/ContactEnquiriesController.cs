using Microsoft.AspNetCore.Mvc;
using UIH.Api.Data;
using UIH.Api.Models;
namespace UIH.Api.Controllers;
public record ContactEnquiryRequest(string FullName,string Email,string? Phone,string Subject,string Message);
[ApiController, Route("api/contact-enquiries")]
public class ContactEnquiriesController(UiHDbContext db) : ControllerBase {
 [HttpPost] public async Task<IActionResult> Create(ContactEnquiryRequest request) {
  if(string.IsNullOrWhiteSpace(request.FullName)||string.IsNullOrWhiteSpace(request.Email)||string.IsNullOrWhiteSpace(request.Subject)||string.IsNullOrWhiteSpace(request.Message))
   return BadRequest("Name, email, subject and message are required.");
  if(request.FullName.Length>120||request.Email.Length>200||request.Subject.Length>200||request.Message.Length>3000)
   return BadRequest("One or more fields exceed the allowed length.");
  var item=new ContactEnquiry{FullName=request.FullName.Trim(),Email=request.Email.Trim(),Phone=request.Phone?.Trim(),Subject=request.Subject.Trim(),Message=request.Message.Trim()};
  db.ContactEnquiries.Add(item); await db.SaveChangesAsync();
  return Created($"/api/contact-enquiries/{item.Id}",new{id=item.Id});
 }
}
