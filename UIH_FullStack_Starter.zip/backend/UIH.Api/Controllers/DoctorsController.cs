using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UIH.Api.Data;
namespace UIH.Api.Controllers;
[ApiController, Route("api/doctors")]
public class DoctorsController(UiHDbContext db) : ControllerBase {
 [HttpGet] public async Task<IActionResult> GetAll([FromQuery]string? specialty=null) {
  var q=db.Doctors.AsNoTracking().Where(x=>x.IsActive);
  if(!string.IsNullOrWhiteSpace(specialty)) q=q.Where(x=>x.Specialty==specialty);
  return Ok(await q.OrderBy(x=>x.FullName).Select(x=>new{x.Id,x.FullName,x.Title,x.Specialty,x.Qualifications,x.Bio,x.ImageUrl,x.Languages,x.IsActive}).ToListAsync());
 }
}
