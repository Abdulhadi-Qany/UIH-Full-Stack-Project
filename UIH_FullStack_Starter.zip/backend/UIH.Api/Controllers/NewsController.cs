using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UIH.Api.Data;
namespace UIH.Api.Controllers;
[ApiController, Route("api/news")]
public class NewsController(UiHDbContext db) : ControllerBase {
 [HttpGet] public async Task<IActionResult> GetAll() =>
  Ok(await db.News.AsNoTracking().Where(x=>x.IsPublished && x.PublishedAt<=DateTime.UtcNow)
   .OrderByDescending(x=>x.PublishedAt).Select(x=>new{x.Id,x.Title,x.Summary,x.ImageUrl,x.PublishedAt}).ToListAsync());
}
