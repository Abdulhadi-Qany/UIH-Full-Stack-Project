using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UIH.Api.Data;
namespace UIH.Api.Controllers;
[ApiController, Route("api/departments")]
public class DepartmentsController(UiHDbContext db) : ControllerBase {
 [HttpGet] public async Task<IActionResult> GetAll() =>
  Ok(await db.Departments.AsNoTracking().Where(x=>x.IsPublished).OrderBy(x=>x.Name)
   .Select(x=>new {x.Id,x.Name,x.Slug,x.Description,x.ImageUrl}).ToListAsync());
 [HttpGet("{slug}")] public async Task<IActionResult> GetBySlug(string slug) {
  var item=await db.Departments.AsNoTracking().Where(x=>x.IsPublished && x.Slug==slug)
   .Select(x=>new {x.Id,x.Name,x.Slug,x.Description,x.ImageUrl}).FirstOrDefaultAsync();
  return item is null ? NotFound() : Ok(item);
 }
}
