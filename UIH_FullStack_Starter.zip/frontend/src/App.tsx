import { useEffect, useMemo, useState } from 'react'
import { Activity, ArrowRight, CalendarDays, ChevronDown, Clock3, HeartPulse, Languages, MapPin, Menu, Phone, ShieldCheck, Stethoscope, X } from 'lucide-react'
import { translations, type Lang } from './i18n'
import { getJson, postJson } from './api'

type Department = { id:number; name:string; description:string; slug:string }
type Doctor = { id:number; fullName:string; title:string; specialty:string; languages:string; isActive:boolean }
type NewsItem = { id:number; title:string; summary:string; publishedAt:string }
const starterDepartments: Department[] = [
 {id:1,name:'Cardiology',slug:'cardiology',description:'Heart and cardiovascular care information.'},
 {id:2,name:'Obstetrics & Gynaecology',slug:'ob-gyn',description:'Women’s health and maternity care information.'},
 {id:3,name:'Paediatrics',slug:'paediatrics',description:'Healthcare information for infants and children.'},
 {id:4,name:'Orthopaedics',slug:'orthopaedics',description:'Bone, joint and musculoskeletal care information.'},
 {id:5,name:'General Surgery',slug:'general-surgery',description:'Surgical consultation and patient information.'},
 {id:6,name:'Radiology & Imaging',slug:'radiology',description:'Diagnostic imaging service information.'},
 {id:7,name:'Laboratory',slug:'laboratory',description:'Laboratory and diagnostic testing information.'},
 {id:8,name:'Emergency Services',slug:'emergency',description:'Emergency service information. Contact the hospital directly for urgent care.'}
]
const starterDoctors: Doctor[] = [
 {id:1,fullName:'Consultant profile to be confirmed',title:'Consultant',specialty:'Cardiology',languages:'Dari, Pashto, English',isActive:true},
 {id:2,fullName:'Consultant profile to be confirmed',title:'Specialist',specialty:'Obstetrics & Gynaecology',languages:'Dari, Pashto',isActive:true},
 {id:3,fullName:'Consultant profile to be confirmed',title:'Specialist',specialty:'Paediatrics',languages:'Dari, Pashto',isActive:true}
]
const starterNews: NewsItem[] = [
 {id:1,title:'Hospital announcements',summary:'Official announcements and updates will appear here after approval by UIH.',publishedAt:''},
 {id:2,title:'Health information',summary:'Patient education content should be reviewed by qualified clinical staff before publication.',publishedAt:''}
]
export default function App() {
 const [lang,setLang] = useState<Lang>(() => (localStorage.getItem('uih-lang') as Lang) || 'en')
 const [page,setPage] = useState('home')
 const [mobileOpen,setMobileOpen] = useState(false)
 const [departments,setDepartments] = useState<Department[]>(starterDepartments)
 const [doctors,setDoctors] = useState<Doctor[]>(starterDoctors)
 const [news,setNews] = useState<NewsItem[]>(starterNews)
 const [query,setQuery] = useState('')
 const [status,setStatus] = useState('')
 const [apiMessage,setApiMessage] = useState('')
 const [form,setForm] = useState({fullName:'',phone:'',email:'',department:'',preferredDate:'',message:''})
 const t = translations[lang]
 const rtl = lang !== 'en'
 useEffect(() => {
  document.documentElement.lang = lang
  document.documentElement.dir = rtl ? 'rtl' : 'ltr'
  localStorage.setItem('uih-lang',lang)
 },[lang,rtl])
 useEffect(() => {
  getJson<Department[]>('/api/departments').then(setDepartments).catch(() => setApiMessage(t.error))
  getJson<Doctor[]>('/api/doctors').then(setDoctors).catch(() => {})
  getJson<NewsItem[]>('/api/news').then(setNews).catch(() => {})
 },[])
 const nav = [
  ['home',t.navHome],['about',t.navAbout],['departments',t.navDepartments],['doctors',t.navDoctors],
  ['services',t.navServices],['patients',t.navPatients],['news',t.navNews],['contact',t.navContact]
 ]
 const filteredDepartments = useMemo(() => departments.filter(d => `${d.name} ${d.description}`.toLowerCase().includes(query.toLowerCase())),[departments,query])
 function go(p:string){setPage(p);setMobileOpen(false);setStatus('');window.scrollTo({top:0,behavior:'smooth'})}
 async function submitAppointment(e:React.FormEvent) {
  e.preventDefault(); setStatus('')
  try {
   await postJson<unknown>('/api/appointment-enquiries',{...form, preferredDate: form.preferredDate || null})
   setStatus(t.success); setForm({fullName:'',phone:'',email:'',department:'',preferredDate:'',message:''})
  } catch {
   setStatus(lang==='en'?'The API is unavailable. Start the backend to submit this enquiry.':lang==='fa'?'سرور در دسترس نیست. برای ارسال درخواست، بخش پشت‌صحنه را اجرا کنید.':'API نه دی فعال. د غوښتنې لپاره backend چالان کړئ.')
  }
 }
 const pageTitle = nav.find(n=>n[0]===page)?.[1] || t.navHome
 return <div className="app-shell">
  <div className="topbar"><span><MapPin size={14}/> Kabul, Afghanistan</span><span><Clock3 size={14}/> Patient information and appointment enquiries</span><a href="tel:+93"><Phone size={14}/> Contact hospital</a></div>
  <header className="header">
   <button className="brand" onClick={()=>go('home')} aria-label="UIH home"><span className="brand-mark"><HeartPulse size={28}/></span><span><b>UMMAT</b><small>INTERNATIONAL HOSPITAL</small></span></button>
   <button className="mobile-toggle" onClick={()=>setMobileOpen(!mobileOpen)} aria-label="Toggle navigation">{mobileOpen?<X/>:<Menu/>}</button>
   <nav className={mobileOpen?'nav open':'nav'}>{nav.map(([id,label])=><button key={id} className={page===id?'active':''} onClick={()=>go(id)}>{label}</button>)}</nav>
   <div className="language"><Languages size={16}/><select value={lang} onChange={e=>setLang(e.target.value as Lang)} aria-label="Language"><option value="en">English</option><option value="fa">دری</option><option value="ps">پښتو</option></select></div>
  </header>
  {page==='home' && <main>
   <section className="hero"><div className="hero-copy"><span className="eyebrow"><Activity size={15}/>{t.heroEyebrow}</span><h1>{t.heroTitle}</h1><p>{t.heroText}</p><div className="hero-actions"><button className="primary" onClick={()=>go('appointment')}>{t.book}<ArrowRight size={18}/></button><button className="secondary" onClick={()=>go('departments')}>{t.navDepartments}</button></div><div className="trust-row"><span><ShieldCheck/> Patient-focused information</span><span><Stethoscope/> Multidisciplinary care</span></div></div><div className="hero-art"><div className="art-circle"><HeartPulse size={94}/></div><div className="floating-card"><span className="pulse-dot"/><div><b>UIH Patient Services</b><small>Appointments · Departments · Information</small></div></div><div className="art-label">Care • Trust • Wellbeing</div></div></section>
   <section className="quick-grid"><button onClick={()=>go('appointment')}><CalendarDays/><b>{t.book}</b><span>Send an appointment enquiry</span></button><button onClick={()=>go('departments')}><Activity/><b>{t.departments}</b><span>Explore specialties</span></button><button onClick={()=>go('doctors')}><Stethoscope/><b>{t.doctors}</b><span>Browse consultant information</span></button><button onClick={()=>go('contact')}><Phone/><b>{t.contact}</b><span>Contact and directions</span></button></section>
   <section className="section"><div className="section-heading"><div><span className="eyebrow">CARE AT UIH</span><h2>{t.departments}</h2><p>{t.departmentsText}</p></div><button className="text-link" onClick={()=>go('departments')}>View all <ArrowRight size={16}/></button></div><div className="card-grid">{departments.slice(0,4).map(d=><article className="info-card" key={d.id}><span className="card-icon"><Activity/></span><h3>{d.name}</h3><p>{d.description}</p><button className="text-link" onClick={()=>go('departments')}>Learn more <ArrowRight size={15}/></button></article>)}</div></section>
   <section className="callout"><div><span className="eyebrow">PATIENT INFORMATION</span><h2>{t.contact}</h2><p>{t.contactText}</p></div><button className="primary" onClick={()=>go('contact')}>{t.navContact}<ArrowRight size={17}/></button></section>
  </main>}
  {page==='about' && <main className="page-main"><span className="eyebrow">UIH</span><h1>{t.about}</h1><p className="lead">{t.aboutText}</p><div className="feature-grid"><article><HeartPulse/><h3>Patient-focused care</h3><p>Publish the hospital’s approved mission, values and care commitments here.</p></article><article><ShieldCheck/><h3>Quality and safety</h3><p>Include only verified quality standards, accreditation and patient-safety information.</p></article><article><Activity/><h3>Modern facilities</h3><p>Add confirmed facility information, photographs and available services.</p></article></div></main>}
  {page==='departments' && <main className="page-main"><span className="eyebrow">FIND A SERVICE</span><h1>{t.departments}</h1><p className="lead">{t.departmentsText}</p><input className="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search departments…" /><div className="card-grid">{filteredDepartments.map(d=><article className="info-card" key={d.id}><span className="card-icon"><Activity/></span><h3>{d.name}</h3><p>{d.description}</p><small>Service availability should be confirmed directly with UIH.</small></article>)}</div>{filteredDepartments.length===0&&<p>No matching departments.</p>}</main>}
  {page==='doctors' && <main className="page-main"><span className="eyebrow">CARE TEAM</span><h1>{t.doctors}</h1><p className="lead">{t.doctorsText}</p><div className="card-grid">{doctors.map(d=><article className="info-card" key={d.id}><span className="card-icon"><Stethoscope/></span><h3>{d.fullName}</h3><b>{d.title}</b><p>{d.specialty}</p><small>{d.languages}</small><button className="text-link" onClick={()=>{setForm({...form,department:d.specialty});go('appointment')}}>{t.book}<ArrowRight size={15}/></button></article>)}</div><p className="notice">Doctor names, qualifications, schedules and availability must be replaced with hospital-verified information before launch.</p></main>}
  {page==='services' && <main className="page-main"><span className="eyebrow">PATIENT SERVICES</span><h1>{t.services}</h1><div className="card-grid">{['Outpatient consultations','Inpatient information','Diagnostic services','Laboratory information','Radiology and imaging','Surgery information','Pharmacy information','Emergency service information'].map(s=><article className="info-card" key={s}><span className="card-icon"><HeartPulse/></span><h3>{s}</h3><p>Details, operating hours, eligibility and availability should be confirmed by UIH before publication.</p></article>)}</div></main>}
  {page==='patients' && <main className="page-main"><span className="eyebrow">PATIENT & FAMILY GUIDE</span><h1>{t.navPatients}</h1><div className="feature-grid">{[['Before your visit','Bring identification and any documents requested by the hospital. Confirm current requirements with UIH.'],['Appointments','Submit an enquiry and wait for the hospital to confirm a time.'],['Admission and discharge','Ask the relevant care team for the current admission, visitor and discharge instructions.'],['Privacy and support','Use official hospital channels for sensitive information and feedback.']].map(([h,p])=><article key={h}><ShieldCheck/><h3>{h}</h3><p>{p}</p></article>)}</div><p className="notice">{t.contactText}</p></main>}
  {page==='news' && <main className="page-main"><span className="eyebrow">LATEST UPDATES</span><h1>{t.news}</h1><div className="card-grid">{news.map(n=><article className="info-card" key={n.id}><span className="card-icon"><Activity/></span><h3>{n.title}</h3><p>{n.summary}</p>{n.publishedAt&&<small>{new Date(n.publishedAt).toLocaleDateString()}</small>}</article>)}</div></main>}
  {page==='appointment' && <main className="page-main narrow"><span className="eyebrow">PATIENT ENQUIRY</span><h1>{t.book}</h1><p className="lead">{t.appointmentNote}</p><form className="form-card" onSubmit={submitAppointment}><div className="form-grid"><label>{t.name}<input required maxLength={120} value={form.fullName} onChange={e=>setForm({...form,fullName:e.target.value})}/></label><label>{t.phone}<input required type="tel" maxLength={40} value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>{t.email}<input type="email" maxLength={200} value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>{t.department}<select required value={form.department} onChange={e=>setForm({...form,department:e.target.value})}><option value="">Select…</option>{departments.map(d=><option key={d.id}>{d.name}</option>)}</select></label><label>{t.date}<input type="date" min={new Date().toISOString().slice(0,10)} value={form.preferredDate} onChange={e=>setForm({...form,preferredDate:e.target.value})}/></label><label className="full">{t.message}<textarea required maxLength={2000} value={form.message} onChange={e=>setForm({...form,message:e.target.value})}/></label></div><p className="privacy-note">Do not include diagnosis, test results, identity numbers, or other sensitive medical details in this form.</p><button className="primary" type="submit">{t.send}<ArrowRight size={17}/></button>{status&&<p className="status" role="status">{status}</p>}</form></main>}
  {page==='contact' && <main className="page-main"><span className="eyebrow">GET IN TOUCH</span><h1>{t.contact}</h1><p className="lead">{t.contactText}</p><div className="contact-grid"><article className="info-card"><MapPin/><h3>Visit UIH</h3><p>Darulaman Road, Kabul, Afghanistan — verify current visitor entrance and directions with the hospital.</p></article><article className="info-card"><Phone/><h3>Telephone</h3><p>Use the official number published by UIH. Confirm current contact details before launch.</p></article><article className="info-card"><Activity/><h3>General enquiries</h3><p>Use the enquiry form for non-urgent questions. Do not submit sensitive health information.</p><button className="primary" onClick={()=>go('appointment')}>Send enquiry</button></article></div></main>}
  <footer className="footer"><div className="footer-top"><div><div className="brand footer-brand"><span className="brand-mark"><HeartPulse/></span><span><b>UMMAT</b><small>INTERNATIONAL HOSPITAL</small></span></div><p>{t.footer}</p></div><div><b>Explore</b>{nav.slice(0,5).map(([id,label])=><button key={id} onClick={()=>go(id)}>{label}</button>)}</div><div><b>Patient resources</b><button onClick={()=>go('patients')}>{t.navPatients}</button><button onClick={()=>go('appointment')}>{t.book}</button><button onClick={()=>go('contact')}>{t.navContact}</button></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} Ummat International Hospital</span><span>Demo website · Verify all official content before launch</span></div></footer>
  {apiMessage&&<div className="api-notice" role="status">{apiMessage}</div>}
 </div>
}
