const base = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'
export async function getJson<T>(path: string): Promise<T> {
  const response = await fetch(`${base}${path}`)
  if (!response.ok) throw new Error(`API error ${response.status}`)
  return response.json() as Promise<T>
}
export async function postJson<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${base}${path}`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body)
  })
  if (!response.ok) {
    const msg = await response.text()
    throw new Error(msg || `API error ${response.status}`)
  }
  return response.json() as Promise<T>
}
