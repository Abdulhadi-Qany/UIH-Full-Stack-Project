export type Lang = 'en' | 'fa' | 'ps'
export const translations: Record<Lang, Record<string,string>> = {
 en: {
  navHome:'Home', navAbout:'About UIH', navDepartments:'Departments', navDoctors:'Doctors', navServices:'Services', navPatients:'Patient Guide', navNews:'News', navContact:'Contact',
  heroEyebrow:'COMPASSIONATE CARE. MODERN MEDICINE.', heroTitle:'Your health deserves thoughtful care.', heroText:'Explore hospital services, meet our care teams, and contact Ummat International Hospital for appointment enquiries and patient information.',
  book:'Request an Appointment', departments:'Medical Departments', departmentsText:'Explore clinical departments and available services.', doctors:'Meet Our Doctors', doctorsText:'Find a specialist and send an appointment enquiry.', services:'Patient Services', news:'News & Health Updates', contact:'Contact UIH',
  name:'Full name', phone:'Phone number', email:'Email address', department:'Department', date:'Preferred date', message:'Message', send:'Send enquiry', appointmentNote:'This form sends an enquiry only. It does not confirm a booking or provide medical advice.',
  about:'About Ummat International Hospital', aboutText:'UIH is presented here as a patient-focused hospital website. Official mission statements, clinical claims, leadership details, and service availability must be confirmed by the hospital before launch.',
  faq:'Frequently Asked Questions', contactText:'For urgent medical emergencies, contact local emergency services or the hospital directly. Do not rely on this website for emergency care.',
  footer:'Ummat International Hospital · Kabul, Afghanistan', allDepartments:'All departments', loading:'Loading…', error:'Could not load live data. Showing approved starter content.', success:'Your enquiry has been submitted. The hospital team can follow up using the details provided.'
 },
 fa: {
  navHome:'صفحهٔ اصلی', navAbout:'دربارهٔ UIH', navDepartments:'بخش‌های طبی', navDoctors:'داکتران', navServices:'خدمات', navPatients:'راهنمای مریضان', navNews:'خبرها', navContact:'تماس',
  heroEyebrow:'مراقبت دلسوزانه، طبابت مدرن', heroTitle:'سلامتی شما شایستهٔ مراقبت دقیق است.', heroText:'با خدمات شفاخانه آشنا شوید، تیم‌های درمانی را ببینید و برای معلومات مریضان یا درخواست وقت با شفاخانه بین‌المللی امت تماس بگیرید.',
  book:'درخواست وقت ملاقات', departments:'بخش‌های طبی', departmentsText:'بخش‌های طبی و خدمات موجود را بررسی کنید.', doctors:'آشنایی با داکتران', doctorsText:'متخصص مورد نظر را پیدا کرده و درخواست وقت بفرستید.', services:'خدمات مریضان', news:'خبرها و معلومات صحی', contact:'تماس با UIH',
  name:'نام مکمل', phone:'شمارهٔ تماس', email:'ایمیل', department:'بخش طبی', date:'تاریخ پیشنهادی', message:'پیام', send:'ارسال درخواست', appointmentNote:'این فورم فقط درخواست معلومات است؛ وقت ملاقات را تأیید نمی‌کند و مشورهٔ طبی ارائه نمی‌دهد.',
  about:'دربارهٔ شفاخانه بین‌المللی امت', aboutText:'این وب‌سایت برای معرفی خدمات شفاخانه و معلومات مریضان طراحی شده است. بیانیهٔ رسمی، معلومات رهبری، ادعاهای طبی و موجودیت خدمات باید پیش از نشر توسط شفاخانه تأیید شود.',
  faq:'پرسش‌های متداول', contactText:'در حالت عاجل طبی با خدمات عاجل محلی یا شفاخانه مستقیماً تماس بگیرید. برای موارد عاجل به این وب‌سایت اتکا نکنید.',
  footer:'شفاخانه بین‌المللی امت · کابل، افغانستان', allDepartments:'تمام بخش‌ها', loading:'در حال بارگذاری…', error:'داده‌های زنده بارگذاری نشد؛ معلومات نمونه نمایش داده می‌شود.', success:'درخواست شما ثبت شد. تیم شفاخانه می‌تواند از طریق معلومات ارائه‌شده پیگیری کند.'
 },
 ps: {
  navHome:'کور', navAbout:'د UIH په اړه', navDepartments:'طبي څانګې', navDoctors:'ډاکټران', navServices:'خدمتونه', navPatients:'د ناروغانو لارښود', navNews:'خبرونه', navContact:'اړیکه',
  heroEyebrow:'مهربانه پاملرنه، عصري درملنه', heroTitle:'ستاسو روغتیا د پاملرنې وړ ده.', heroText:'د روغتون له خدمتونو سره بلد شئ، د درملنې ټیمونه وګورئ او د ناروغانو د معلوماتو یا ملاقات غوښتنې لپاره له امت نړیوال روغتون سره اړیکه ونیسئ.',
  book:'د ملاقات غوښتنه', departments:'طبي څانګې', departmentsText:'طبي څانګې او شته خدمتونه وګورئ.', doctors:'زموږ ډاکټران', doctorsText:'متخصص ومومئ او د ملاقات غوښتنه واستوئ.', services:'د ناروغانو خدمتونه', news:'خبرونه او روغتیايي معلومات', contact:'له UIH سره اړیکه',
  name:'بشپړ نوم', phone:'د ټیلیفون شمېره', email:'برېښنالیک', department:'څانګه', date:'غوښتل شوې نېټه', message:'پیغام', send:'غوښتنه واستوئ', appointmentNote:'دا فورمه یوازې غوښتنه لېږي؛ ملاقات نه تاییدوي او طبي مشوره نه وړاندې کوي.',
  about:'د امت نړیوال روغتون په اړه', aboutText:'دا وېبپاڼه د روغتون د معلوماتو او د ناروغانو د لارښوونې لپاره طرحه شوې. رسمي ماموریت، د مشرتابه معلومات، طبي ادعاوې او د خدمتونو شتون باید د خپرېدو مخکې د روغتون له خوا تایید شي.',
  faq:'ډېرې پوښتل شوې پوښتنې', contactText:'په طبي بېړني حالت کې له سیمه‌ییزو بېړنیو خدمتونو یا روغتون سره مستقیمه اړیکه ونیسئ. د بېړنۍ درملنې لپاره پر دې وېبپاڼه تکیه مه کوئ.',
  footer:'امت نړیوال روغتون · کابل، افغانستان', allDepartments:'ټولې څانګې', loading:'د بارولو په حال کې…', error:'ژوندي معلومات نه دي پورته شوي؛ د نمونې معلومات ښودل کېږي.', success:'ستاسو غوښتنه ثبت شوه. د روغتون ټیم د ورکړل شوو معلوماتو له لارې اړیکه نیولی شي.'
 }
}
