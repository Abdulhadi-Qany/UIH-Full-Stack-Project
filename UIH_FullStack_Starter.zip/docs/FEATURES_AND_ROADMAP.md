# UIH feature catalogue and production roadmap

## Public website
- Responsive home page and hospital identity
- About, departments, doctor directory, services, patient guide
- News/health updates, contact, careers, education/research, tenders, FAQs
- English, Dari, Pashto with RTL layouts
- Appointment and contact enquiry forms
- SEO metadata, accessible navigation, clear emergency disclaimer

## Content management (next milestone)
Implement a protected CMS for:
- Department CRUD and localized fields
- Doctor profiles, qualifications, specialties, schedule text, languages and portrait
- Service pages and FAQs
- News articles and publishing workflow
- Career vacancies and tender announcements
- Media library, content revisions and approval workflow
- Role separation: ContentEditor, Publisher, Admin

## Administration (next milestone)
- Secure login, MFA, password reset, session revocation
- Dashboard metrics for enquiries and content
- Enquiry triage, assignment, status history, export with permission checks
- Audit trail, staff account management, role and permission matrix
- Rate limits, anti-spam, retention controls, and access logging

## Clinical/operational systems excluded from this starter
Patient EMR/EHR, clinical notes, diagnosis, prescriptions, laboratory results, imaging, pharmacy, billing, insurance, inpatient management, PACS, HL7/FHIR integrations, and clinical decision support require a separate requirements process and security/clinical review. They are not implemented by this public website starter.

## Acceptance checklist
- [ ] UIH verifies all official content and contact details
- [ ] Professional Dari/Pashto medical-language review
- [ ] Full keyboard and screen-reader checks
- [ ] API validation, rate limiting and anti-spam
- [ ] Authentication, authorization, MFA and audit tests
- [ ] Automated unit/integration/end-to-end tests
- [ ] HTTPS, secrets management, backups, monitoring and restore drills
- [ ] Privacy, legal, retention, consent and incident-response approval
- [ ] Load and penetration testing
- [ ] Deployment runbook and rollback plan
