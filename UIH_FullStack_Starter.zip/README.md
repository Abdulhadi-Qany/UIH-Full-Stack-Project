# Ummat International Hospital (UIH) — Full-Stack Starter

A full-stack, multilingual hospital website and administration starter for UIH.

## Stack
- Frontend: React + Vite + TypeScript
- Backend: ASP.NET Core Web API (.NET 8)
- Database: PostgreSQL via Entity Framework Core
- Auth: ASP.NET Core Identity/JWT-ready foundation
- Localization: English, Dari, Pashto; RTL-aware layout
- API docs: Swagger/OpenAPI in Development

## Included modules
- Public website: Home, About, Departments, Doctors, Services, Patient Guide, News, Careers, Contact, FAQs
- Appointment enquiry workflow
- Contact enquiry workflow
- Admin dashboard starter
- Departments and doctors API
- News API
- Authentication/authorization foundation
- Audit log entity and role-based access pattern
- Docker Compose for PostgreSQL
- Environment configuration templates

## Important
This is a development starter, not a certified hospital information system or production deployment. Do not store real patient records or sensitive health information until UIH has completed security, privacy, clinical, legal, hosting, backup, and operational reviews. Appointment enquiries here are website enquiries, not confirmed bookings. Do not add diagnosis, prescriptions, medical records, billing, or clinical workflows without a separately scoped and reviewed system.

## Run locally

### Prerequisites
- Node.js 20+
- .NET 8 SDK
- Docker Desktop (or a local PostgreSQL server)

### 1. Start PostgreSQL
From this directory:
```bash
docker compose up -d db
```

### 2. Start API
```bash
cd backend/UIH.Api
dotnet restore
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```
Swagger is available at the API URL shown in the terminal, typically `/swagger`.

### 3. Start frontend
In a second terminal:
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Open the local Vite URL. Set `VITE_API_BASE_URL` in `.env` to the API base URL shown by `dotnet run`.

## Before production
- Replace demo content with UIH-approved copy, doctor profiles, departments, photographs, and contact details.
- Add verified official Dari and Pashto translations and have medical terminology reviewed by qualified speakers.
- Implement an approved email/SMS notification provider and secure appointment handling.
- Configure HTTPS, secrets management, rate limiting, anti-spam, monitoring, backups, disaster recovery, and a security incident process.
- Add automated tests, accessibility testing, penetration testing, and privacy/legal review.
- Restrict admin access with MFA and least-privilege roles.
- Configure retention/deletion policy and avoid collecting unnecessary sensitive information.
