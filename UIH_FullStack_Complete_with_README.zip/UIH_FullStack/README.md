# Ummat International Hospital (UIH) — Full-Stack Website

A multilingual public-facing website starter for **Ummat International Hospital (UIH)**, designed as a foundation for hospital information, service discovery, doctor and department listings, patient guidance, news, contact messages, and appointment enquiries.

> **Project status:** Development starter / prototype. This repository is not a production-ready hospital information system, and the included appointment form is an enquiry workflow—not a confirmed booking system.

## Contents

- [Highlights](#highlights)
- [Technology stack](#technology-stack)
- [Project structure](#project-structure)
- [Requirements](#requirements)
- [Run locally](#run-locally)
- [Configuration](#configuration)
- [API and data](#api-and-data)
- [Languages and right-to-left layout](#languages-and-right-to-left-layout)
- [Docker](#docker)
- [Development checklist](#development-checklist)
- [Security and patient privacy](#security-and-patient-privacy)
- [Deployment checklist](#deployment-checklist)
- [Contributing](#contributing)
- [License](#license)

## Highlights

- Hospital landing page and informational sections
- Departments, doctors, services, patient guide, news, careers, FAQs, and contact content areas
- Appointment enquiry and contact enquiry workflows
- Starter admin-dashboard interface and API foundations
- English, Dari, and Pashto localization foundations with RTL-aware presentation
- ASP.NET Core API and PostgreSQL/Entity Framework Core foundation
- Docker Compose configuration for local database development
- Environment-variable example files
- Swagger/OpenAPI intended for development use

**Please verify the implementation before relying on any listed capability.** Authentication, admin CRUD, notifications, and production safeguards may require further implementation; this starter should not be treated as a completed clinical or hospital-management platform.

## Technology stack

| Layer | Technology |
| --- | --- |
| Frontend | React, TypeScript, Vite |
| UI icons | Lucide React |
| Backend | ASP.NET Core Web API (.NET 8) |
| Data access | Entity Framework Core |
| Database | PostgreSQL |
| Local database | Docker Compose |
| API documentation | Swagger/OpenAPI in development |

## Project structure

```text
UIH_FullStack/
├── frontend/
│   ├── src/
│   │   ├── App.tsx          # Main website UI
│   │   ├── api.ts           # API client/helpers
│   │   ├── i18n.ts          # Language/localization foundation
│   │   ├── main.tsx         # React entry point
│   │   └── styles.css       # Global styling
│   ├── .env.example
│   ├── index.html
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts
├── backend/
│   └── UIH.Api/
│       ├── Program.cs
│       ├── UIH.Api.csproj
│       └── appsettings.json
├── docs/
│   └── FEATURES_AND_ROADMAP.md
├── docker-compose.yml
├── .gitignore
└── README.md
```

## Requirements

Install the following tools before running the project:

- **Node.js 20 or later** and npm
- **.NET 8 SDK**
- **Docker Desktop** with Docker Compose, or a PostgreSQL server you manage
- Git (optional, for cloning and version control)

## Run locally

Run commands from the repository root unless otherwise stated.

### 1. Get the project

```bash
git clone https://github.com/Abdulhadi-Qany/UIH-Full-Stack-Project.git
cd UIH-Full-Stack-Project
```

If you are working from a downloaded ZIP, extract it and open the extracted project folder in VS Code.

### 2. Start PostgreSQL

```bash
docker compose up -d db
```

Check the service status with:

```bash
docker compose ps
```

### 3. Configure and run the API

Open a terminal in the API directory:

```bash
cd backend/UIH.Api
dotnet restore
dotnet run
```

Use the local URL printed by the .NET CLI. If Swagger is enabled for the current environment, open `/swagger` on that URL.

**Database setup note:** Before using database-backed endpoints, confirm that the configured connection string matches your local PostgreSQL service and that the project's EF Core migrations/schema are present. If migrations are not included, create and apply them after confirming the `DbContext` and entity configuration:

```bash
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```

Run migration commands from `backend/UIH.Api`. Do not create duplicate migrations if a suitable migration already exists.

### 4. Configure and run the frontend

Open a second terminal:

```bash
cd frontend
npm install
```

Copy the example environment file:

**Windows PowerShell**

```powershell
Copy-Item .env.example .env
```

**macOS / Linux**

```bash
cp .env.example .env
```

Set `VITE_API_BASE_URL` in `frontend/.env` to the API base URL printed by `dotnet run`, then start Vite:

```bash
npm run dev
```

Open the local URL printed by Vite (commonly `http://localhost:5173`). Keep the API and frontend terminals running while developing.

### 5. Build the frontend

```bash
cd frontend
npm run build
```

This runs TypeScript project checks and creates a production frontend build in `frontend/dist`. A successful frontend build does not by itself validate the API, database connectivity, security, or end-to-end workflows.

## Configuration

- `frontend/.env.example` documents frontend environment variables. Keep local secrets and `.env` files out of version control.
- `backend/UIH.Api/appsettings.json` contains application configuration defaults. Use environment variables or a secrets manager for deployment-specific secrets and credentials.
- Confirm the database connection string, CORS policy, API URL, and environment-specific settings before connecting the frontend to the API.
- Never commit real passwords, access tokens, production connection strings, private keys, or patient data.

## API and data

The backend is intended to provide a foundation for public website data and enquiry submissions, including departments, doctors, news, appointment enquiries, and contact enquiries. Check the current controllers/endpoints and database setup in the source before integrating another application; do not assume every planned endpoint or admin operation is fully implemented.

Appointment and contact forms should be treated as **requests for follow-up**. Do not display a success message that implies an appointment is confirmed unless a real scheduling workflow verifies availability and records confirmation.

## Languages and right-to-left layout

The project includes localization foundations for:

- English (`en`)
- Dari (`fa-AF` or the locale configured in the app)
- Pashto (`ps-AF` or the locale configured in the app)

Review `frontend/src/i18n.ts` and the language controls to confirm the exact locale identifiers and translation coverage. Before public launch, have all Dari and Pashto text—including medical terms, navigation labels, forms, validation messages, and accessibility labels—reviewed by qualified speakers. Test RTL direction, alignment, mixed-script text, numbers, and mobile layouts on real devices.

## Docker

The root `docker-compose.yml` is provided for local development and currently focuses on PostgreSQL. Review the compose file before use, especially database credentials, ports, volumes, and health checks. Do not expose a development database publicly.

## Development checklist

- [ ] Confirm all pages, links, forms, and language controls work as intended
- [ ] Replace sample content with UIH-approved content and contact information
- [ ] Obtain approval for doctor names, credentials, schedules, departments, images, and service descriptions
- [ ] Complete and test API validation, error handling, and database migrations
- [ ] Implement secure admin authentication and authorization before exposing admin features
- [ ] Add automated frontend, backend, integration, and end-to-end tests
- [ ] Add accessible labels, keyboard navigation, focus states, and screen-reader testing
- [ ] Test responsive layouts on phones, tablets, and desktop screens
- [ ] Verify spam protection and server-side input validation for every public form
- [ ] Add monitored email/SMS notifications only after selecting and configuring an approved provider

## Security and patient privacy

This project is a **website starter**, not a certified hospital information system or electronic medical record. Do not enter, store, or transmit real patient records, diagnoses, prescriptions, laboratory results, payment details, or other sensitive health information using this prototype.

Before any real-world deployment, UIH and its qualified technical, legal, privacy, and clinical stakeholders should review the system and its hosting environment. At minimum, assess:

- HTTPS/TLS and secure headers
- Authentication, authorization, least privilege, and multi-factor authentication for staff
- Server-side validation, output encoding, CSRF protections where applicable, rate limiting, and abuse prevention
- Secret management and rotation
- Encryption at rest and in transit where appropriate
- Audit logging that avoids recording sensitive data unnecessarily
- Backup restoration and disaster-recovery procedures
- Data retention, deletion, consent, privacy notices, and applicable legal obligations
- Vulnerability scanning, dependency updates, penetration testing, monitoring, and incident response

Do not use this public website to collect clinical details. Keep public enquiry forms limited to the minimum information needed for follow-up, and provide clear guidance for urgent medical needs through UIH-approved content.

## Deployment checklist

Before publishing to a live domain:

1. Use separate development, staging, and production environments.
2. Configure production secrets outside source control.
3. Use managed PostgreSQL or a properly secured and maintained database service.
4. Configure HTTPS, CORS, allowed hosts, logging, monitoring, backups, and alerts.
5. Disable development-only tools such as Swagger in production unless explicitly secured and approved.
6. Add a production web server/CDN and configure SPA routing and caching correctly.
7. Run automated tests, accessibility checks, security reviews, and restore drills.
8. Obtain written approval from UIH for all public content, branding, translations, and contact details.
9. Verify that enquiry submissions reach the intended authorized staff and that users receive accurate confirmation messages.
10. Document ownership, maintenance responsibilities, incident contacts, and update procedures.

## Contributing

1. Create a feature branch.
2. Keep changes focused and include tests where practical.
3. Do not commit secrets, credentials, production data, or patient information.
4. Document configuration changes and update this README when setup steps change.
5. Open a pull request describing the change and how it was tested.

## License

No license has been specified in this starter. Add a `LICENSE` file only after the project owner has selected and approved the license terms.

---

**Maintainer:** Abdulhadi Qany  
**Repository:** https://github.com/Abdulhadi-Qany/UIH-Full-Stack-Project
